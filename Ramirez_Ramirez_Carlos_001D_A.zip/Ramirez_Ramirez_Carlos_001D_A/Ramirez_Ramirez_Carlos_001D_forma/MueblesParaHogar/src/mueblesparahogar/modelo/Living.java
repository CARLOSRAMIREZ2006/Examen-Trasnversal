/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mueblesparahogar.modelo;

/**
 *
 * @author Duoc
 */
public class Living extends Mueble{
    
    private int numeroSofa;
    private boolean incluyeCojines;

    public Living(int id, String nombre, double precio, int numeroSofa, boolean incluyeCojines) {
        super(id, nombre, precio);
        this.numeroSofa = numeroSofa;
        this.incluyeCojines = incluyeCojines;
    }
    
    @Override
    public String mostrarDetalle(){
        return "Living , ID: " + id +
                "Sofas: " + numeroSofa +
                "Cojines: " + incluyeCojines +
                "Precio: $" + precio;
    }
}
