/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mueblesparahogar.modelo;

/**
 *
 * @author Duoc
 */
public class Bistro extends Mueble{
    
    private double diametroMesa;

    public Bistro(int id, String nombre, double precio, double diametroMesa) {
        super(id, nombre, precio);
        this.diametroMesa = diametroMesa;
    }
    
    @Override
    public String mostrarDetalle(){
        return "Bistro , ID: " + id + 
                "Diametro: " + diametroMesa + 
                "Precio: " + precio;
    }
    
}
