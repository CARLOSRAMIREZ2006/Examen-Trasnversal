/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mueblesparahogar.modelo;

/**
 *
 * @author Duoc
 */
public class Comedor extends Mueble{
    private int capacidadPersonas;
    
    public Comedor(int id, String nombre, double precio, int cantidadPersonas) {
        super(id, nombre, precio);
        this.capacidadPersonas = cantidadPersonas;
    }
    
    @Override 
    public String mostrarDetalle(){
        return "Comedor , id: " + id + 
                " , Capacidad: " + capacidadPersonas +
                " personas , precio: $" + precio;
    }
}
