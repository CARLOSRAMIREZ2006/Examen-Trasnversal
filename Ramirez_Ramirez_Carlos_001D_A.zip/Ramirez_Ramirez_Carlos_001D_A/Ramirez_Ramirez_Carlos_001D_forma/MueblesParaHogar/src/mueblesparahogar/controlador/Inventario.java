/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mueblesparahogar.controlador;
/**
 *
 * @author Duoc
 */

import java.util.ArrayList;
import mueblesparahogar.modelo.Mueble;

public class Inventario {

    private ArrayList<Mueble> listaMuebles;

    public Inventario() {
        listaMuebles = new ArrayList<>();
    }

    public void agregarMueble(Mueble mueble) {
        listaMuebles.add(mueble);
    }

    public void eliminarMueble(int id) {
        listaMuebles.removeIf(m -> m.getId() == id);
    }

    public ArrayList<Mueble> listarMuebles() {
        return listaMuebles;
    }
}

